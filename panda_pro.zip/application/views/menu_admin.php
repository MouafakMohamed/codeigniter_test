
    <div class="main-menu menu-fixed menu-light menu-accordion menu-shadow hide" data-scroll-to-active="true">
        <div class="navbar-header">
            <ul class="nav navbar-nav flex-row">
                <li class="nav-item mr-auto"><a class="navbar-brand">
                        <div class="brand-logo"><img src="<?php echo base_url(); ?>upload/panda2.png" style="width: 160px;height: 50px;padding-left: 30px" ></div>
                    </a></li>
            </ul>
        </div>
        <div class="shadow-bottom"></div>
        <div class="main-menu-content">
            <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
               <li class=" nav-item"><a href="dashboard_admin"><i class="feather icon-bar-chart"></i><span class="menu-title" data-i18n="Email">Tableau de Bord</span></a>
                </li>
				    <li class=" nav-item"><a href="#"><i class="feather icon-users"></i><span class="menu-title" data-i18n="Ecommerce"> Tracabilité</span></a>
                </li>
                <!--<li class=" nav-item"><a href="<?php echo base_url(); ?>assets/#"><i class="feather icon-shuffle"></i><span class="menu-title" data-i18n="Ecommerce">Traçabilité</span></a>
                    <ul class="menu-content">
                       
                        <li><a href="Entrer"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Wish List">Entrer</span></a>
                        </li>
                        <li><a href="Sortir"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Checkout">Sortir</span></a>
                        </li>
							<li><a href="tracabilite_client"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Checkout">Client</span></a>
                        </li>
						<li><a href="tracabilite_produit"><i class="feather icon-circle"></i><span class="menu-item" data-i18n="Checkout">Produit</span></a>
                        </li>
                    </ul>
                </li>-->
				<li class=" nav-item"><a href="comptabilite"><i class="feather icon-bar-chart-2"></i><span class="menu-title" data-i18n="Calender">Comptabilité</span></a>
                </li>
             	<li class=" nav-item"><a href="SAV"><i class="feather icon-alert-triangle"></i><span class="menu-title" data-i18n="Calender">SAV</span></a>
                </li>
                <li class=" nav-item"><a href="commande"><i class="feather icon-circle icon-clipboard"></i><span class="menu-title" data-i18n="Calender">Commande</span></a> </li>
                <li class=" nav-item"><a href="dipot"><i class="feather icon-layout"></i><span class="menu-title" data-i18n="Calender">Les dépôt</span></a>
                </li>
			 
            </ul>
        </div>
    </div>
